// TODO: extract values into env
export const appConfig = {
	baseUrl: `http://109.94.172.191:8081/api/`
};
