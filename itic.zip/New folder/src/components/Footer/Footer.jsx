import { Container } from "./styles";

function Footer() {
  return (
    <Container>
        <Container.Link>En | Ru</Container.Link>
      <Container.Link>Telegram</Container.Link>
      <Container.Link>Instagram</Container.Link>
      <Container.Link>Facebook</Container.Link>
      <Container.Link>LinkedIn</Container.Link>
      <Container.Link>+90 123-45-67</Container.Link>
    </Container>
  );
}

export default Footer;
